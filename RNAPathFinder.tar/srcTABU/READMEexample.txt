The name of the TABU algorithm implementation by I. Dotu is
     get_barrier
located in srcTABU.tgz

The code compiles on Linux/Unix but not on Macintosh OS X.

To unpack on Linux machine:
    tar zxvf srcTABU.tgz
to obtain the directory srcTABU.

Change directories to srcTABU, type
  make clean
then
  make
to obtain the executable "get_barrier"

HOW TO RUN CODE:
    ./get_barrier rna str1 str2 iteratiions minWt maxWt  energyBd

where
  rna: RNA sequence in upper or lower case, e.g. GGGCCCC
  str1: initial RNA sec structure enclosed in single quotes, e.g. '((...))'
  str2: final RNA sec structure enclosed in single quotes, e.g. '..(...)'
note that rna,str1,str2 must all have identical lengths.
  iterations: number of trajectories to return
  minWt: minimum weight (lower bound on weighting function)
  maxWt: maximum weight (lower bound on weighting function)
For explanation of minWt and maxWt, see article.
  energyBd: return folding trajectories whose barrier energy <= energyBd
            where the energy bound is given in Kcal/mol 

OUTPUT:
 - For each iteration:
        - Best Path
        - barrier energy in Kcal/mol
        - length of the path
        - value of initial weight for the best path


===================================================================
EXAMPLE: Consider a bistable switch with RNA sequence
    CUUAUGAGGGUACUCAUAAGAGUAUCC
initial structure
    ((((((((....)))))))).......  with free energy of -9.90 determined by RNAeval
final structure
    .......((((((((....)))))))) with free energy of -10.30 determined by RNAeval

We initially try
    ./get_barrier CUUAUGAGGGUACUCAUAAGAGUAUCC '((((((((....)))))))).......' '.......((((((((....))))))))' 5 10 70 12
then we are asking for 5 trajectories, using recommended minWt of 10 
maxWt of 70 and an energy bound of 10; i.e. we are searching for a 
folding pathway in which every intermediate structure has free energy 
AT MOST (-9.90 + 12) = +2.10 kcal/mol

We find that no path is found with this energy bound, so we now increase
the energy bound to 16, and immediately find some folding pathways

===================================================================
One should capture the output by output redirection, e.g.

    ./get_barrier CUUAUGAGGGUACUCAUAAGAGUAUCC '((((((((....)))))))).......' '.......((((((((....))))))))' 5 10 70 16 > output.txt

and then write a script for further analysis, such as the best folding 
trajectory out of all iterations, whether folding trajectories tend to
share certain traits, etc.


Good luck!

then we are asking for 5 trajectories, using recommended minWt of 10 
